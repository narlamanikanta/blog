//
//  ViewController.swift
//  Final
//
//  Created by Student on 19/10/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITableViewDelegate, UITableViewDataSource {
    var username = String()
   
  
    
   


        let cons: [String] = ["Politics","Technology","Celebrities","Business"]
    var topic = String()
    var actor = 1
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cons.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseCell", for: indexPath)
        
        cell.textLabel?.text = cons[indexPath.row]
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if(actor == 1){
            let homeView: HomeViewController = segue.destination as! HomeViewController
            
            homeView.topic = topic
            homeView.user = username
        }
        return
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let value = cons[indexPath.row]
        topic = value
        actor = 1
        if(indexPath.section == 0){
                 performSegue(withIdentifier: "home", sender: self)
        }

        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        usernameField.text = username
    }
    @IBOutlet weak var usernameField: UILabel!
    
    
    
    @IBAction func loginBtn(_ sender: Any) {
        actor = 2
        performSegue(withIdentifier: "login", sender: self)
    }
    
}

