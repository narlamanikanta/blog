//
//  HomeViewController.swift
//  Final
//
//  Created by Student on 19/10/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController , UITableViewDataSource, UITableViewDelegate{
    
    var user = String()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return newsTitles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "newsCell", for: indexPath)
        
        cell.textLabel?.text = newsTitles[indexPath.row]
        cell.detailTextLabel?.text = newsDetails[indexPath.row]
        cell.imageView?.image = newsImages[indexPath.row]
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectedIndex = indexPath.row
        
        performSegue(withIdentifier: "read", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let readView: ReadViewController = segue.destination as! ReadViewController
        
        readView.index = selectedIndex
        readView.topic = self.topic
        readView.image = self.newsImages[selectedIndex]
        readView.date = self.dates[selectedIndex]
        readView.newsTitle = self.newsTitles[selectedIndex]
        readView.author = self.authors[selectedIndex]
        readView.user = self.user
    }
    
    

    @IBOutlet weak var banner: UIImageView!
    
    @IBOutlet weak var topicLabel: UILabel!
    
    var topic = String()
    var selectedIndex = 0
    var newsDetails = [String]()
    var newsImages = [UIImage]()
    var newsTitles = [String]()
    var authors = [String]()
    var dates = [String]()
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        topicLabel.text = topic
       
    
    switch topic {
        case "Politics":
            newsTitles = ["IAEA Initiates Investigations on ‘Dirty Bomb’ Claims in Ukraine","A new Prime Minister for UK","Sunak vows to protect mortgage holders, but says he can’t ‘do everything","Russia withdraws from Black Sea Grain Initiative","Nobel Peace Prize 2022"]
            newsDetails = ["Russia’s allegations accusing Ukraine of producing dirty bombs","Rishi Sunak is the incumbent Prime Minister, succeeding Liz Truss on 25 October 2022,","Ukrainian Troops advance their territory protection beyond Kyiv","TRussia recently pulled out of the Black Sea Grain Deal","has been conferred to human rights advocate Ales Bialiatski"]
            newsImages = [
                UIImage(named: "ukrain.jpg")!,
                UIImage(named: "rishisunak.jpeg")!,
                UIImage(named: "sunak.jpeg")!,
                UIImage(named: "russian.jpeg")!,
                UIImage(named: "peace.jpeg")!,
                ]
            authors = ["Renly Wood","Katelin Stark","Simbisai Wana","Maya Aimes","Maya Aimes"]
            dates = ["November 4, 2022","November 1, 2022","October 29, 2022","October 28, 2022","October 28, 2022"]
            banner.animationImages = newsImages
            banner.animationDuration = 15
            banner.startAnimating()
            break
    
        case "Technology":
            newsTitles = ["Netflix Basic with ads subscription won’t work on these devices","Twitter Faces Lawsuit for Mass Layoffs","IT spending in India to grow 6% in 2021: Gartner","Samsung India sells mobile phones worth Rs 14,400 crore between Sept-Oct"]
            newsDetails = ["Popular OTT platform Netflix has recently launched a lower-priced subscription","Twitter is facing lawsuit that claims the layoffs violate the WARN Act","It is set to witness a rise of 6% in 2021","mobile phone business grew by 20%"]
            newsImages = [
            UIImage(named: "netflix.jpg")!,
            UIImage(named: "twitter.jpeg")!,
            UIImage(named: "ITspending.jpg")!,
            UIImage(named: "samsung.jpeg")!,
            ]
            authors = ["Renly Wood","Katelin Stark","Simbisai Wana","Maya Aimes"]
            dates = ["November 4, 2022","November 1, 2022","October 29, 2022","October 28, 2022"]
            banner.animationImages = newsImages
            banner.animationDuration = 15
            banner.startAnimating()
    case "Celebrities":
        newsTitles = ["2022 CFDA Awards","Shilpa Shetty does Surya Namaskar","Aditya Seal relives school days","Boney Kapoor says movies will never be successful"]
        newsDetails = ["What the Stars Wore to the 2022 CFDA Awards","Three months after leg injury, Shilpa Shetty does Surya Namaskar","From fun games to shaking a leg, Aditya Seal relives school days","if actors wrap up their films in 25-30 days"]
        newsImages = [
            UIImage(named: "kim.jpeg")!,
            UIImage(named: "twitter.jpeg")!,
            UIImage(named: "AdityaSeal.jpeg")!,
            UIImage(named: "boney_kapoor.jpeg")!,
        ]
        authors = ["Renly Wood","Katelin Stark","Simbisai Wana","Maya Aimes"]
        dates = ["November 4, 2022","November 1, 2022","October 29, 2022","October 28, 2022"]
        banner.animationImages = newsImages
        banner.animationDuration = 15
        banner.startAnimating()
        
    case "Business":
        newsTitles = [
            "IndiGo Q2 loss widens by 10%"
            ,"Paytm Q2 loss widens to Rs 571.5 crore"
            ,"EU says it has serious concerns about Biden’s Inflation Reduction Act"
            ,"Adani Group continues to seek equity partners"]
        
        newsDetails = [
            "An increase in fuel expenses due to a weaker rupee"
            ,"On a sequential basis, the September FY23 quarter loss by One 97"
            ,"The European Union has “serious concerns”"
            ,"India's ports-to-energy conglomerate Adani Group continues"]
        newsImages = [
            UIImage(named: "car3.jpeg")!,
            UIImage(named: "paytm.jpeg")!,
            UIImage(named: "biden.jpeg")!,
            UIImage(named: "adani.png")!,
        ]
        authors = ["Renly Wood","Katelin Stark","Simbisai Wana","Maya Aimes"]
        dates = ["November 4, 2022","November 1, 2022","October 29, 2022","October 28, 2022"]
        banner.animationImages = newsImages
        banner.animationDuration = 15
        banner.startAnimating()
        default:
            break
       }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBOutlet weak var mode1: UILabel!
    @IBOutlet weak var background: UIImageView!
    @IBAction func mode(_ sender: UISwitch) {
        if(sender.isOn==true){
            mode1.text="Turn on dark Mode"
            background.image=UIImage(named: "marbo_liston_light_grey.jpeg")
        }
        else{
            mode1.text="Turn on Light Mode"
            background.image=UIImage(named: "grey1.jpeg")
        }
    }
    
}

