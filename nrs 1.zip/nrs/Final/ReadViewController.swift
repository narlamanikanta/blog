//
//  ReadViewController.swift
//  Final
//
//  Created by Student on 02/11/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class ReadViewController: UIViewController {

    var index = 0
    var topic = ""
    var image = UIImage()
    var newsTitle = ""
    var date = ""
    var views = ""
    var author = ""
    var content = ""
    var user = ""
    var liked = false
    var saved = false
    override func viewDidLoad() {
        super.viewDidLoad()
        likeImg.layer.transform = CATransform3DMakeScale(0.0, 0.0, 0.0)
        saveBtn.layer.transform = CATransform3DMakeScale(0.0, 0.0, 0.0)
        // Do any additional setup after loading the view.
        switch topic {
            case "Politics":
                content = PoliticsContent[index]
            case "Technology":
                content = TechContent[index]
            case "Celebrities":
                content = CelebContent[index]
            case "Business":
                content = BusinessContent[index]
            default:
                break
        }
        
        newsBody.text = content
        titleLabel.text = newsTitle
        authorLabel.text = author
        viewsLabel.text = "100K views"
        dateLabel.text = date
        newsImage.image = image
        
    }
    

    @IBAction func LikeBtn(_ sender: UIButton) {
        if(user == "")
        {
            let alert = UIAlertController(title:"Login First", message: "You're not logged in", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: {(action: UIAlertAction)->Void in
                
            }))
            
            self.present(alert, animated: true,completion: nil)
        }
        else{
            if(liked)
            {
                likeImg.layer.transform = CATransform3DMakeScale(0.0, 0.0, 0.0)
                liked = false
            }
            else{
                likeImg.layer.transform = CATransform3DIdentity
                liked = true
            }
            
        }
    }
    
    @IBAction func saveBtn(_ sender: Any) {
        if(user != ""){
        let alert = UIAlertController(title:"Save News Article", message: "Choose where you want to save", preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Favorites", style: .default, handler: {(action: UIAlertAction)->Void in
            if(self.saved){
                self.saveBtn.layer.transform = CATransform3DMakeScale(0.0, 0.0, 0.0)
                self.saved = false
            }else{
                self.saveBtn.layer.transform = CATransform3DIdentity
                self.saved = true
            }
            
        }))
        alert.addAction(UIAlertAction(title: "Read letter", style: .default, handler: {(action: UIAlertAction)-> Void in
            if(self.saved){
                self.saveBtn.layer.transform = CATransform3DMakeScale(0.0, 0.0, 0.0)
                self.saved = false
            }else{
                self.saveBtn.layer.transform = CATransform3DIdentity
                self.saved = true
            }
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: {(UIAlertAction)-> Void in
            self.saveBtn.layer.transform = CATransform3DMakeScale(0.0, 0.0, 0.0)
            self.saved = false
        }))
        
        
        self.present(alert, animated: true,completion: nil)
        }
        else
        {
            let alert = UIAlertController(title:"Login First", message: "You're not logged in", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: {(action: UIAlertAction)->Void in
                
            }))
            
            self.present(alert, animated: true,completion: nil)
        }
    }
    
    

    
    
    @IBOutlet weak var newsImage: UIImageView!
    @IBOutlet weak var newsBody: UITextView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var viewsLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var saveBtn: UIImageView!
    @IBOutlet weak var likeImg: UIImageView!
    let PoliticsContent = ["The UN’s nuclear watchdog International Atomic Energy Agency (IAEA) recently initiated investigations on Russia’s allegations accusing Ukraine of producing dirty bombs. What are dirty bombs? Dirty bomb is a conventional explosive device laced with toxic materials. Unlike a nuclear weapon, it does not cause atomic explosion. Rather, it spreads radioactive, biological or chemical wastes after",
                           
        "LONDON — Rishi Sunak becomes Britain's third prime in under two months at a time when the U.K. faces what he has termed a \"profound economic challenge\" and as his Conservative Party struggles to heal divisive wounds from months of infighting. \nHe now leads the Conservatives with a substantial parliamentary majority inherited since the 2019 general election, when his former boss Boris Johnson helped win seats in areas of Britain that had never traditionally voted for the center right party.     Rishi Sunak will become the next U.K. prime minister \nEUROPE Rishi Sunak will become the next U.K. prime minister\"It is only right to explain why I am standing here as your new prime minister,\" Sunak told the crowd of journalists gathered outside No. 10 Downing Street's famous front door, after formally accepting his new role from King Charles during a meeting at Buckingham Palace.",
        
        "Rishi Sunak has vowed to limit the impact of rising inflation on people with mortgages, as he promised to rebuild trust in the government.The prime minister said inflation was the number one enemy and that he was doing everything he could to grip the issue.Sunak told the Times he understood the concerns of families now facing crippling rises in their monthly mortgage bills, after the Bank of England increased base interest rates by 0.75 percentage points to 3% – their highest level in 15 years.\n I absolutely recognise the anxiety that people have about mortgages. It’s one of the biggest bills people have, he said.",
        
        "Russia recently pulled out of the Black Sea Grain Deal, which was launched to mitigate food inflation caused by conflict in Ukraine. What is Black Sea Grain Initiative? The Black Sea Grain Initiative was an agreement between Russia and Ukraine with Turkey and the United Nations. It sought to create a safe passage of food ",
        
        "On October 7, Nobel Peace Prize for 2022 has been conferred to human rights advocate Ales Bialiatski from Belarus, Ukrainian human rights organization named Center for Civil Liberties and Russian human rights organisation Memorial. Key facts With the Nobel Peace Prize being conferred to individuals or organizations from Belarus, Russia and Ukraine, implicit message is"
    ]
    
    
    
    let TechContent = ["Popular OTT platform Netflix has recently launched a lower-priced subscription tier called ‘Basic with ads’ that offers 720p content streaming with ad breaks. The company has reportedly published a support page to announce the devices that won’t support the latest Netflix Basic with ads subscription tier.  \n\nNetflix Basic with ads subscription: Unsupported devices\n\nAccording to a report by 9to5Google, the new less expensive Netflix plan will not support older Chromecast devices. Only the latest models, that come with Google TV will support the latest Netflix subscription tier.\n\nThe Basic, Standard, or Premium ad-free Netflix plans will be available for the older Chromecast or Chromecast Ultra devices. The Netflix support page also notes that phones and tablets need to run Android 7.0 or above for this plan.",
                       
           "Twitter has begun laying off employees under its new owner, Elon Musk. The San Francisco-based social media giant is expected to terminate up to 3,700 people — half of its workforce — on Friday, according to internal plans reviewed by Reuters this week. Twitter is already facing a proposed class action claiming the layoffs are imminent and will violate US and California laws if employees are not given advance notice or severance pay.\n\nWhat does US law require?\n\n The federal Worker Adjustment and Retraining Notification (WARN) Act requires businesses with 100 or more employees to provide 60 days' notice before engaging in mass layoffs. The law defines mass layoffs as those affecting at least 500 employees during a 30-day period, or at least 50 employees if layoffs impact at least one-third of a company's workforce. Employers can provide workers with 60 days of severance pay in lieu of giving notice.",
       
           "IT spending in India is set to witness a rise of 6% in 2021 and reach $81.9 billion in 2021, according to the latest forecast by research agency Gartner. While in 2020, it is expected to total $79.3 billion, down 8.4% from 2019.\n\nAs per the report, in 2020, devices and data centre systems segments experienced the steepest declines, as spending dropped 26% and 1.2%, respectively. The maximum growth, however, was seen in the enterprise software segment of 7%. Other segments such as IT services and communication services were new by 3.7% and 4.9% respectively.",
       
           "Samsung India sold mobile phones worth Rs 14,400 crore between September-October and recorded 99 per cent growth in the premium category smartphones in the first three quarters of 2022, a senior company official said on Friday.\n\nSamsung India senior director and head of product marketing Aditya Babbar told PTI that the company recorded a 178 per cent jump in sales in value terms of 5G smartphones between January-September 2022 on a year-over-year basis.\n\n\"Samsung had a record festive season this year. This was an outstanding performance on account of great revenue which we posted of Rs 14,400 crore in a 60-day period starting September 1,\" he said.\n\nWithout disclosing the exact percentage, Babbar said that the growth was in the healthy double-digit compared to sales during the festive period last year.\n\nHe said that Samsung Finance Plus was one of the key contributors to the growth and the transaction on the platform tripled to over 10 lakh during the festive season.\n\n\"The growth has been much better in tier 2 and 3 towns but it has done phenomenally well in urban centres as well,\" Babbar said."]
    
    
    
    let CelebContent = ["Strike a pose! The 2022 CFDA Awards showcased stars in some of their most jaw-dropping attire to date. \n\nThe fashion extravaganza, which was held at the Cipriani South Street in New York City on Monday, November 7, honored the “best and brightest” in American fashion. The stylish soiree was hosted by Orange Is the New Black alum Natasha Lyonne.\n\nThe A-list affair, presented in partnership with Amazon Fashion, commemorated the 60th anniversary of the CFDA (Countil of Fashion Designers of America) — a non-profit organization first launched by storied publicist Eleanor Lambert. Kim Kardashian, Lenny Kravitz and renowned designer Law Roach were just a few of the night’s honorees. \n\nGuest or winner, every celebrity showed up serving larger-than-life looks. Katie Holmes, for her part, dazzled in a Jonathan Sitka silver slip dress, which was held together by diamonds. The gown, which included a fabulous fringe hem, gave the Dawson’s Creek alum a full old Hollywood glamour aesthetic as she walked the red carpet.\n\nKravitz – the 2022 Fashion Icon Award winner — stunned in a LaQuan Smith all-black suit, with flared leather pants and a fringed tuxedo jacket. The musician tied the look together with various rings, three layered silver necklaces and a pair of oversized sunnies.",
                        
        "Shilpa Shetty, who, on the occasion of Gurpurab on Tuesday, successfully managed to do the Surya Namaskar three months after a serious leg injury that had left her immobile, has said that it was her self-belief that had enabled her to recover.\n\nTaking to Instagram to post a video of her doing the Surya Namaskar on Tuesday, Shilpa Shetty quoted Guru Nanak and said: \"'He who has no faith in himself can never have faith in God.' - Guru Nanak Dev ji.\n\n\"This teaching has stayed with me for many years now, and I believe very strongly in it. Believing in yourself and having faith that you can do anything you set your mind to is one of the best ways to lead a wholesome life.\n\"With this in mind - on the special occasion of Gurpurab, I practised the Surya Namaskara for the first time again, three months after my injury.\"\n\"Being able to achieve this milestone after being wheelchair-bound for weeks is an indescribable feeling.\"\nThe actress also wished all her followers on the occasion. She wrote: \"Mere aur mere poore parivaar ki taraf se Guru Nanak Dev ji ke Parkash Parv ki aap sabhi ko dheron shubhkaamnayein.\"",
            
        "Boney Kapoor recently expressed his displeasure about the actors who wrap up their movies in limited days of time. According to him, that is one of the reasons why films fail at the box office.\n\nBoney, who graced Kapil Sharma’s chat show with his daughter Janhvi Kapoor to promote ‘Mili’, said that there are many actors who work for 25-30 days and want full fees. According to him, their intentions are wrong right from the beginning. Although he didn’t name any actors, he revealed that there are quite a few of them. The filmmaker also went on to add that those actors want to work in a limited time. They ask ‘how long will the shoot go on?’ According to Kapoor, they want to work at their convenience. That is one of the reasons why the film doesn’t work. He also added that unless there is honesty, the film will never be a success. Netizens started speculating who the actors could be; many assumed this remark could be about Akshay Kumar.",
            
        "Bollywood actor Aditya Seal is leaving no stone unturned to promote his upcoming film 'Rocket Gang'. And what could be a better place than his old school to talk about the movie, which is about childhood friends.\n\nAt his alma mater, CNM School, Vile Parle, Mumbai, Aditya couldn't contain his excitement. He said: \"Being around these kids today, I couldn't help but recollect my childhood days. The school's atmosphere made me extremely nostalgic as I remembered all the fun I had with all my friends.\"\n\nAditya also taught the children the signature step of his movie and the kids, in turn, played a number of games with him that reminded the 'Tum Bin II' actor of his school days.\"It was so much fun interacting with the kids, they're just so cheerful and full of life that it brightened up my day. We danced and played games and it was definitely the most fun I've had during promotions,\" he added.\n\nDirected by Bosco Martis, the movie 'Rocket Gang', is produced by Zee Studios. It features Aditya Seal and Nikita Dutta in lead roles. The movie is all set to release in theatres on November 11."]
    
    
    
    let BusinessContent = [
    "An increase in fuel expenses due to a weaker rupee and a surge in employee costs eroded margins. However, the total revenue from operations for the quarter jumped 123 per cent to Rs 12,479 crore following an 80 per cent increase in passenger numbers to 19.7 million. InterGlobe Aviation, the parent company of IndiGo, India’s largest carrier, on Friday saw its standalone net loss widen by 10 per cent to Rs 1,585 crore for the three months ended September. The loss reported was higher than the Bloomberg estimate of Rs 1,284.5 crore.\n\nAn increase in fuel expenses due to a weaker rupee and a surge in employee costs eroded margins. However, the total revenue from operations for the quarter jumped 123 per cent to Rs 12,479 crore following an 80 per cent increase in passenger numbers to 19.7 million."
        
        ,"One 97 Communications, the operator of mobile payments and financial services company Paytm, has posted a consolidated loss of Rs 571.5 crore for the quarter ended September FY23, widening from a loss of Rs 473.5 crore in same period last year. However, the loss narrowed from Rs 645.4 crore recorded in Q1FY23.\n\nConsolidated revenue from operations for the quarter at Rs 1,914 crore increased by 76.2 percent over corresponding period last fiscal. The sequential increase in top line was 14 percent.\n\nThe top line growth was driven by increase in merchant subscription revenues, growth in bill payments due to growing MTU (monthly transaction user) and growth in disbursements of loans through the platform, Paytm said in its BSE filing on November 7.\n\nThe company further said its payments services revenue grew 56 percent YoY, led by continued platform expansion across MTU, merchant base, subscription merchants and GMV (gross merchandise value)."
        
        ,"BRUSSELS — The European Union has “serious concerns” about the U.S. Inflation Reduction Act, saying it breaches international trade rules, according to an official document seen by CNBC.\n\nThe sweeping tax, health and climate bill was approved by U.S. lawmakers in August and includes a record $369 billion in spending on climate and energy policies. The landmark package comprises tax credits for electric cars made in North America and supports U.S. battery supply chains.\n\nEuropean officials have acknowledged the green ambitions associated with the package, but they are worried about “the way that the financial incentives under the Act are designed,” the document, which will be presented to U.S. officials, says. The EU listed nine of the tax credit provisions that it has an issue with.\n\nSpeaking in Brussels, the EU’s trade chief said, “We have established a taskforce to deal with these issues ... we are currently concentrating on finding a negotiated solution.”\n\n“Hopefully, there is willingness from the U.S. to address the concerns which we are having in the EU side,” Valdis Dombrovskis told CNBC."
        
        ,"India's ports-to-energy conglomerate Adani Group continues to seek strategic equity partners aligned with its long-term investment strategy, debt research firm CreditSights said in a report, flagging concern over the Group's elevated leverage.\n\nThe Group, led by Asia's richest person Gautam Adani, is looking to expand its presence in power generation and infrastructure and ventured into cement-making operations earlier this year.\n\nChairman Adani said late in September that the\n\ngroup will invest more than $100 billion over the next decade, most of it in the energy transition business. CreditSights said the conglomerate is venturing into new or unrelated businesses which are highly capital intensive.\n\nIt has plans for four business verticals including energy and utility, transport and logistics, materials metals and mining, and consumer, said CreditSights.\n\n\"We still hold our view that several of the Group companies maintain elevated leverage owing to aggressive expansion plans, that are largely debt-funded and that have pressurized their credit metrics and cash flows,\" said the report dated Nov. 4, which was shared with Reuters on Monday."]
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    class news {
        var title = String()
        var detail = String()
        
        func news(_ title: String, _ detail: String) -> Void {
            self.title = title
            self.detail = detail
        }
    }
    
}
