//
//  LoginViewController.swift
//  Final
//
//  Created by Student on 05/11/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
        var authenticate = false
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(authenticate){
            let View: ViewController = segue.destination as! ViewController
            View.username = usernameField.text!
        }
    }


    @IBOutlet weak var usernameField: UITextField!
    
    @IBOutlet weak var passwordField: UITextField!
    
    @IBAction func loginBtn(_ sender: Any) {
        let username = usernameField.text!
        let password = passwordField.text!
        var message = ""
        
        if(username == "" || username.count <= 2){
            message = "Username too short or empty"
        }
        else if(password != "nrs1"){
            message = "Wrong password, try again"
        }
        else {
            authenticate = true
            performSegue(withIdentifier: "start", sender:self)
            return
        }
        authenticate = false
        let alert = UIAlertController(title: "Authentication Failed", message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        
        present(alert, animated: true, completion: nil)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
